/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author Francisco
 */
public class Modelo {
    private String cidade;
    private String rua;
    private int numero;
    private int localizacao;
    private String marca;
    private float km;
    private String tipo;
    private Date data_partida;
    private int cod_armazem;
    private int cod_loja_saida;
    private int cod_loja_chegada;
    private int cod_caminhao;
    private int cod_pacote;
    private float peso;
    private float volume;
    private Date data_limite;

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(int localizacao) {
        this.localizacao = localizacao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public float getKm() {
        return km;
    }

    public void setKm(float km) {
        this.km = km;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getData_partida() {
        return data_partida;
    }

    public void setData_partida(Date data_partida) {
        this.data_partida = data_partida;
    }

    public int getCod_armazem() {
        return cod_armazem;
    }

    public void setCod_armazem(int cod_armazem) {
        this.cod_armazem = cod_armazem;
    }

    public int getCod_loja_saida() {
        return cod_loja_saida;
    }

    public void setCod_loja_saida(int cod_loja_saida) {
        this.cod_loja_saida = cod_loja_saida;
    }

    public int getCod_loja_chegada() {
        return cod_loja_chegada;
    }

    public void setCod_loja_chegada(int cod_loja_chegada) {
        this.cod_loja_chegada = cod_loja_chegada;
    }

    public int getCod_caminhao() {
        return cod_caminhao;
    }

    public void setCod_caminhao(int cod_caminhao) {
        this.cod_caminhao = cod_caminhao;
    }

    public int getCod_pacote() {
        return cod_pacote;
    }

    public void setCod_pacote(int cod_pacote) {
        this.cod_pacote = cod_pacote;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public Date getData_limite() {
        return data_limite;
    }

    public void setData_limite(Date data_limite) {
        this.data_limite = data_limite;
    }
}
