/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Francisco
 */
public class Conexao {
    public Connection conector;
    
    //Com tratamento de exceção
    public void Conectar(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/NomeBanco";
            String usuario = "root";
            String senha = "";
            conector = DriverManager.getConnection(url, usuario, senha);
        } catch(ClassNotFoundException ex){
            System.out.println("Erro no Driver" + ex.getMessage()); 
        } catch(SQLException ex){
            System.out.println("Erro na conexão com banco" + ex.getMessage());
        }
    }
    
    public void Desconectar(){
        try{
            conector.close();
        } catch(SQLException e){
            System.out.println("Erro no encerramento!" + e.getMessage());
        }
    }
    
}
