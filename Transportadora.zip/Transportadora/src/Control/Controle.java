/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Modelo;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import util.Conexao;

/**
 *
 * @author Francisco
 */
public class Controle {
    public String salvarEndereço(Modelo modelo){
        String retorno = "Erro!";
        Conexao con = new Conexao();
        con.Conectar();
        String sql = "insert into endereco values {?,?,?}";
        try {
            PreparedStatement sentenca = con.conector.prepareStatement(sql);
            sentenca.setString(1, modelo.getCidade());
            sentenca.setString(2, modelo.getRua());
            sentenca.setInt(3, modelo.getNumero());
            if(!sentenca.execute()){
                retorno = "Dados inseridos comsucesso";
            }
        } catch (SQLException ex) {
            System.out.println("Erro na sentença de inserir!" + ex.getMessage());
        }
        con.Desconectar();
        return retorno;
    }
    public String salvarLoja(Modelo modelo){
        String retorno = "Erro!";
        Conexao con = new Conexao();
        con.Conectar();
        String sql = "insert into endereco values {?,?,?}";
        try {
            PreparedStatement sentenca = con.conector.prepareStatement(sql);
            sentenca.setString(1, modelo.getCidade());
            sentenca.setString(2, modelo.getRua());
            sentenca.setInt(3, modelo.getNumero());
            if(!sentenca.execute()){
                retorno = "Dados inseridos comsucesso";
            }
        } catch (SQLException ex) {
            System.out.println("Erro na sentença de inserir!" + ex.getMessage());
        }
        con.Desconectar();
        return retorno;
    }
}
